# FotoRapiAI currently ships without minification.
