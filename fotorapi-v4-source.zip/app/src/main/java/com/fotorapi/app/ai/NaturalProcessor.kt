package com.fotorapi.app.ai

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

object NaturalProcessor {

    fun apply(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(
            source.width,
            source.height,
            Bitmap.Config.ARGB_8888
        )

        val saturation = ColorMatrix().apply { setSaturation(1.06f) }
        val contrast = ColorMatrix(
            floatArrayOf(
                1.03f, 0f, 0f, 0f, -3.2f,
                0f, 1.03f, 0f, 0f, -3.2f,
                0f, 0f, 1.03f, 0f, -3.2f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        saturation.postConcat(contrast)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(saturation)
        }

        Canvas(result).drawBitmap(source, 0f, 0f, paint)
        return result
    }
}
