package com.fotorapi.app.ai

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

object PhotoSaver {

    fun saveJpeg(context: Context, bitmap: Bitmap): Boolean {
        val name = "FotoRapiAI_${System.currentTimeMillis()}.jpg"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(
                    MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/FotoRapiAI"
                )
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }

            val uri = context.contentResolver.insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                values
            ) ?: return false

            return try {
                context.contentResolver.openOutputStream(uri).use { out ->
                    requireNotNull(out)
                    check(bitmap.compress(Bitmap.CompressFormat.JPEG, 98, out))
                }

                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                context.contentResolver.update(uri, values, null, null)
                true
            } catch (_: Throwable) {
                context.contentResolver.delete(uri, null, null)
                false
            }
        }

        @Suppress("DEPRECATION")
        val pictures = Environment.getExternalStoragePublicDirectory(
            Environment.DIRECTORY_PICTURES
        )
        val dir = java.io.File(pictures, "FotoRapiAI")
        if (!dir.exists()) dir.mkdirs()

        val file = java.io.File(dir, name)
        return try {
            file.outputStream().use { out ->
                check(bitmap.compress(Bitmap.CompressFormat.JPEG, 98, out))
            }
            true
        } catch (_: Throwable) {
            false
        }
    }
}
