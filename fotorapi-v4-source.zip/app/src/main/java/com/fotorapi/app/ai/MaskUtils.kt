package com.fotorapi.app.ai

import android.graphics.Bitmap
import java.nio.ByteBuffer

data class MaskBounds(
    val left: Int,
    val top: Int,
    val rightExclusive: Int,
    val bottomExclusive: Int
)

object MaskUtils {

    fun toAlphaBytes(mask: Bitmap): ByteArray {
        require(mask.config == Bitmap.Config.ALPHA_8) { "Mask must be ALPHA_8" }
        val bytes = ByteArray(mask.width * mask.height)
        mask.copyPixelsToBuffer(ByteBuffer.wrap(bytes))
        return bytes
    }

    fun findEraseBounds(mask: ByteArray, width: Int, height: Int): MaskBounds? {
        var left = width
        var top = height
        var right = -1
        var bottom = -1

        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                if ((mask[row + x].toInt() and 0xFF) < 128) {
                    if (x < left) left = x
                    if (y < top) top = y
                    if (x > right) right = x
                    if (y > bottom) bottom = y
                }
            }
        }

        if (right < 0) return null
        return MaskBounds(left, top, right + 1, bottom + 1)
    }

    fun starts(
        size: Int,
        boundStart: Int,
        boundEndExclusive: Int,
        tile: Int = 512,
        overlap: Int = 128
    ): List<Int> {
        if (size <= tile) return listOf(0)

        val stride = tile - overlap
        val safeHalf = overlap / 2
        val first = ((boundStart - safeHalf).coerceAtLeast(0) / stride) * stride
        val set = linkedSetOf<Int>()

        var s = first
        while (s < size && s < boundEndExclusive) {
            if (s + tile > boundStart) set += s
            s += stride
        }

        set += (size - tile).coerceAtLeast(0)

        return set
            .filter { it < size && it + tile > boundStart && it < boundEndExclusive }
            .sorted()
    }
}
