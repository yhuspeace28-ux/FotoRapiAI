package com.fotorapi.app

import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.fotorapi.app.ai.BitmapUtils
import com.fotorapi.app.ai.MiganInpainter
import com.fotorapi.app.ai.NaturalProcessor
import com.fotorapi.app.ai.PhotoSaver
import com.fotorapi.app.ui.DrawingView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var drawingView: DrawingView
    private lateinit var status: TextView
    private lateinit var btnPick: Button
    private lateinit var btnNatural: Button
    private lateinit var btnClear: Button
    private lateinit var btnAI: Button
    private lateinit var btnSave: Button

    private var currentBitmap: android.graphics.Bitmap? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val pickPhoto = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) loadPhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.fotorapi.app.R.layout.activity_main)

        imageView = findViewById(com.fotorapi.app.R.id.imgOriginal)
        drawingView = findViewById(com.fotorapi.app.R.id.drawingView)
        status = findViewById(com.fotorapi.app.R.id.txtStatus)
        btnPick = findViewById(com.fotorapi.app.R.id.btnPick)
        btnNatural = findViewById(com.fotorapi.app.R.id.btnNatural)
        btnClear = findViewById(com.fotorapi.app.R.id.btnClear)
        btnAI = findViewById(com.fotorapi.app.R.id.btnProcessAI)
        btnSave = findViewById(com.fotorapi.app.R.id.btnSave)

        btnPick.setOnClickListener { pickPhoto.launch("image/*") }
        btnClear.setOnClickListener {
            drawingView.clear()
            status.text = "Mask direset."
        }
        btnNatural.setOnClickListener { applyNatural() }
        btnAI.setOnClickListener { removeObject() }
        btnSave.setOnClickListener { saveCurrent() }

        imageView.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            updateImageRect()
        }
        setBusy(false)
    }

    private fun loadPhoto(uri: Uri) {
        setBusy(true)
        status.text = "Membuka foto…"

        worker.execute {
            try {
                val bitmap = BitmapUtils.loadOrientedBitmap(this, uri)
                runOnUiThread {
                    currentBitmap?.recycle()
                    currentBitmap = bitmap
                    imageView.setImageBitmap(bitmap)
                    drawingView.clear()
                    updateImageRect()
                    status.text = "Siap. Coret objek yang ingin dihapus."
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Gagal membuka foto."
                    Toast.makeText(
                        this,
                        t.message ?: "Format foto tidak didukung",
                        Toast.LENGTH_LONG
                    ).show()
                    setBusy(false)
                }
            }
        }
    }

    private fun updateImageRect() {
        val bitmap = currentBitmap ?: return

        drawingView.post {
            val vw = drawingView.width.toFloat()
            val vh = drawingView.height.toFloat()
            if (vw <= 0f || vh <= 0f) return@post

            val scale = minOf(
                vw / bitmap.width.toFloat(),
                vh / bitmap.height.toFloat()
            )
            val dw = bitmap.width * scale
            val dh = bitmap.height * scale
            val left = (vw - dw) / 2f
            val top = (vh - dh) / 2f

            drawingView.setImageRect(
                RectF(left, top, left + dw, top + dh)
            )
        }
    }

    private fun applyNatural() {
        val source = currentBitmap ?: run {
            status.text = "Pilih foto dulu."
            return
        }

        setBusy(true)
        status.text = "Menerapkan warna natural…"

        worker.execute {
            try {
                val result = NaturalProcessor.apply(source)
                runOnUiThread {
                    currentBitmap?.recycle()
                    currentBitmap = result
                    imageView.setImageBitmap(result)
                    drawingView.clear()
                    updateImageRect()
                    status.text = "Warna natural diterapkan."
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "Natural gagal: ${t.message ?: "error"}"
                    setBusy(false)
                }
            }
        }
    }

    private fun removeObject() {
        val source = currentBitmap ?: run {
            status.text = "Pilih foto dulu."
            return
        }

        val mask = drawingView.buildKeepMask(source.width, source.height)
        setBusy(true)
        status.text = "AI offline memproses…"

        worker.execute {
            try {
                MiganInpainter(this).use { engine ->
                    val result = engine.inpaint(source, mask) { done, total ->
                        runOnUiThread {
                            status.text = "AI offline: $done/$total bagian"
                        }
                    }

                    runOnUiThread {
                        currentBitmap?.recycle()
                        currentBitmap = result
                        imageView.setImageBitmap(result)
                        drawingView.clear()
                        updateImageRect()
                        status.text =
                            "Selesai. Resolusi ${result.width}×${result.height} tetap."
                        setBusy(false)
                    }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status.text = "AI gagal."
                    Toast.makeText(
                        this,
                        "Model MI-GAN tidak bisa dijalankan: ${t.message ?: "unknown"}",
                        Toast.LENGTH_LONG
                    ).show()
                    setBusy(false)
                }
            } finally {
                mask.recycle()
            }
        }
    }

    private fun saveCurrent() {
        val bitmap = currentBitmap ?: run {
            status.text = "Tidak ada hasil untuk disimpan."
            return
        }

        setBusy(true)
        status.text = "Menyimpan foto…"

        worker.execute {
            val ok = PhotoSaver.saveJpeg(this, bitmap)
            runOnUiThread {
                status.text = if (ok) {
                    "Tersimpan di Pictures/FotoRapiAI."
                } else {
                    "Gagal menyimpan foto."
                }
                Toast.makeText(
                    this,
                    if (ok) "Foto tersimpan" else "Gagal menyimpan",
                    Toast.LENGTH_SHORT
                ).show()
                setBusy(false)
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        btnPick.isEnabled = !busy
        btnNatural.isEnabled = !busy && currentBitmap != null
        btnClear.isEnabled = !busy && currentBitmap != null
        btnAI.isEnabled = !busy && currentBitmap != null
        btnSave.isEnabled = !busy && currentBitmap != null
    }

    override fun onDestroy() {
        worker.shutdownNow()
        currentBitmap?.recycle()
        currentBitmap = null
        super.onDestroy()
    }
}
