package com.fotorapi.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val path = Path()
    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 72f
        color = Color.argb(150, 255, 64, 129)
    }

    private var activeStroke = false
    private var imageRect = RectF()

    fun setImageRect(rect: RectF) {
        imageRect.set(rect)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!path.isEmpty) {
            canvas.drawPath(path, previewPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!imageRect.contains(event.x, event.y)) {
                    activeStroke = false
                    return true
                }
                activeStroke = true
                path.reset()
                path.moveTo(event.x, event.y)
                invalidate()
                performClick()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (activeStroke) {
                    path.lineTo(event.x, event.y)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                if (activeStroke) {
                    path.lineTo(event.x, event.y)
                    invalidate()
                }
                activeStroke = false
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun clear() {
        path.reset()
        invalidate()
    }

    fun setBrushSize(size: Float) {
        previewPaint.strokeWidth = size.coerceIn(8f, 300f)
        invalidate()
    }

    fun buildKeepMask(sourceWidth: Int, sourceHeight: Int): Bitmap {
        val mask = Bitmap.createBitmap(
            max(1, sourceWidth),
            max(1, sourceHeight),
            Bitmap.Config.ALPHA_8
        )

        val maskCanvas = Canvas(mask)
        maskCanvas.drawColor(Color.WHITE)

        if (path.isEmpty || imageRect.width() <= 0f || imageRect.height() <= 0f) {
            return mask
        }

        val sx = sourceWidth.toFloat() / imageRect.width()
        val sy = sourceHeight.toFloat() / imageRect.height()

        val matrix = Matrix().apply {
            setScale(sx, sy)
            postTranslate(-imageRect.left * sx, -imageRect.top * sy)
        }

        val sourcePath = Path()
        path.transform(matrix, sourcePath)

        val erasePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = previewPaint.strokeWidth * ((sx + sy) * 0.5f)
            color = Color.TRANSPARENT
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }

        // Alpha 255 = keep, alpha 0 = erase.
        maskCanvas.drawPath(sourcePath, erasePaint)

        return mask
    }
}
