package com.fotorapi.app.ai

import android.content.Context
import android.graphics.Bitmap
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import java.io.Closeable
import kotlin.math.min

class MiganInpainter(context: Context) : Closeable {

    private val model: CompiledModel
    private val inputBuffers
    private val outputBuffers

    private val input = FloatArray(4 * 512 * 512)

    init {
        model = try {
            CompiledModel.create(
                context.assets,
                "migan_fp16.tflite",
                CompiledModel.Options(Accelerator.GPU, Accelerator.CPU),
                null
            )
        } catch (_: Throwable) {
            CompiledModel.create(
                context.assets,
                "migan_fp16.tflite",
                CompiledModel.Options(Accelerator.CPU),
                null
            )
        }

        inputBuffers = model.createInputBuffers()
        outputBuffers = model.createOutputBuffers()
    }

    fun inpaint(
        source: Bitmap,
        keepMask: Bitmap,
        onProgress: ((done: Int, total: Int) -> Unit)? = null
    ): Bitmap {
        require(source.width == keepMask.width && source.height == keepMask.height)

        val width = source.width
        val height = source.height
        val maskBytes = MaskUtils.toAlphaBytes(keepMask)

        val bounds = MaskUtils.findEraseBounds(maskBytes, width, height)
            ?: return source.copy(Bitmap.Config.ARGB_8888, true)

        val xStarts = MaskUtils.starts(width, bounds.left, bounds.rightExclusive)
        val yStarts = MaskUtils.starts(height, bounds.top, bounds.bottomExclusive)
        val total = xStarts.size * yStarts.size

        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        var done = 0

        for (tileY in yStarts) {
            for (tileX in xStarts) {
                if (tileIntersectsErase(maskBytes, width, height, tileX, tileY)) {
                    val output = runTile(source, maskBytes, width, height, tileX, tileY)
                    pasteCenter(
                        result,
                        maskBytes,
                        width,
                        height,
                        tileX,
                        tileY,
                        output
                    )
                }

                done++
                onProgress?.invoke(done, total)
            }
        }

        return result
    }

    private fun tileIntersectsErase(
        mask: ByteArray,
        width: Int,
        height: Int,
        tileX: Int,
        tileY: Int
    ): Boolean {
        val xEnd = min(width, tileX + 512)
        val yEnd = min(height, tileY + 512)

        for (y in tileY until yEnd) {
            val row = y * width
            for (x in tileX until xEnd) {
                if ((mask[row + x].toInt() and 0xFF) < 128) return true
            }
        }
        return false
    }

    private fun runTile(
        source: Bitmap,
        keepMask: ByteArray,
        width: Int,
        height: Int,
        tileX: Int,
        tileY: Int
    ): FloatArray {
        val actualW = min(512, width - tileX)
        val actualH = min(512, height - tileY)
        val region = IntArray(actualW * actualH)

        source.getPixels(
            region,
            0,
            actualW,
            tileX,
            tileY,
            actualW,
            actualH
        )

        val plane = 512 * 512

        for (yy in 0 until 512) {
            val sy = (tileY + yy).coerceAtMost(height - 1)
            val regionRow = (sy - tileY) * actualW
            val inputRow = yy * 512

            for (xx in 0 until 512) {
                val sx = (tileX + xx).coerceAtMost(width - 1)
                val color = region[regionRow + (sx - tileX)]

                val keep = (keepMask[sy * width + sx].toInt() and 0xFF) / 255f
                val r = ((color shr 16) and 0xFF) / 127.5f - 1f
                val g = ((color shr 8) and 0xFF) / 127.5f - 1f
                val b = (color and 0xFF) / 127.5f - 1f

                input[inputRow + xx] = keep - 0.5f
                input[plane + inputRow + xx] = r * keep
                input[2 * plane + inputRow + xx] = g * keep
                input[3 * plane + inputRow + xx] = b * keep
            }
        }

        inputBuffers[0].writeFloat(input)
        model.run(inputBuffers, outputBuffers)
        return outputBuffers[0].readFloat()
    }

    private fun pasteCenter(
        result: Bitmap,
        maskBytes: ByteArray,
        width: Int,
        height: Int,
        tileX: Int,
        tileY: Int,
        output: FloatArray
    ) {
        val margin = 64

        val left = if (tileX == 0) 0 else margin
        val top = if (tileY == 0) 0 else margin
        val right = if (tileX + 512 >= width) min(512, width - tileX) else 512 - margin
        val bottom = if (tileY + 512 >= height) min(512, height - tileY) else 512 - margin

        val destW = right - left
        val destH = bottom - top
        if (destW <= 0 || destH <= 0) return

        val pixels = IntArray(destW * destH)
        result.getPixels(
            pixels,
            0,
            destW,
            tileX + left,
            tileY + top,
            destW,
            destH
        )

        val plane = 512 * 512
        var i = 0

        for (yy in top until bottom) {
            val y = tileY + yy
            val maskRow = y * width

            for (xx in left until right) {
                val x = tileX + xx
                if ((maskBytes[maskRow + x].toInt() and 0xFF) < 128) {
                    val oi = yy * 512 + xx
                    val r = ((output[plane + oi] + 1f) * 127.5f).coerceIn(0f, 255f).toInt()
                    val g = ((output[2 * plane + oi] + 1f) * 127.5f).coerceIn(0f, 255f).toInt()
                    val b = ((output[3 * plane + oi] + 1f) * 127.5f).coerceIn(0f, 255f).toInt()
                    pixels[i] = 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
                }
                i++
            }
        }

        result.setPixels(
            pixels,
            0,
            destW,
            tileX + left,
            tileY + top,
            destW,
            destH
        )
    }

    override fun close() {
        inputBuffers.forEach { it.close() }
        outputBuffers.forEach { it.close() }
        model.close()
    }
}
