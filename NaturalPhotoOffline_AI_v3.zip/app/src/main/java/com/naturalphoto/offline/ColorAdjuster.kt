package com.naturalphoto.offline

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

object ColorAdjuster {

    /** Conservative, natural-looking correction. Keeps image dimensions unchanged. */
    fun natural(source: Bitmap): Bitmap {
        val src = source.copy(Bitmap.Config.ARGB_8888, false)
        val pixels = IntArray(src.width * src.height)
        src.getPixels(pixels, 0, src.width, 0, 0, src.width, src.height)

        var mean = 0.0
        val sampleStep = max(1, pixels.size / 10000)
        var samples = 0
        var i = 0
        while (i < pixels.size) {
            val p = pixels[i]
            mean += (0.2126 * ((p ushr 16) and 255) +
                0.7152 * ((p ushr 8) and 255) +
                0.0722 * (p and 255)) / 255.0
            samples++
            i += sampleStep
        }
        mean = if (samples > 0) mean / samples else 0.5
        val exposure = (0.5 / max(0.20, min(0.80, mean))).pow(0.65).coerceIn(0.88, 1.12)
        val contrast = 1.04
        val saturation = 1.03

        for (idx in pixels.indices) {
            val p = pixels[idx]
            val r0 = ((p ushr 16) and 255) / 255.0
            val g0 = ((p ushr 8) and 255) / 255.0
            val b0 = (p and 255) / 255.0

            var r = (r0 * exposure - 0.5) * contrast + 0.5
            var g = (g0 * exposure - 0.5) * contrast + 0.5
            var b = (b0 * exposure - 0.5) * contrast + 0.5

            val l = 0.2126 * r + 0.7152 * g + 0.0722 * b
            r = l + (r - l) * saturation
            g = l + (g - l) * saturation
            b = l + (b - l) * saturation

            pixels[idx] = BitmapColor.argb(
                255,
                (r * 255).roundToInt().coerceIn(0, 255),
                (g * 255).roundToInt().coerceIn(0, 255),
                (b * 255).roundToInt().coerceIn(0, 255)
            )
        }

        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        out.setPixels(pixels, 0, src.width, 0, 0, src.width, src.height)
        src.recycle()
        return out
    }

    private object BitmapColor {
        fun argb(a: Int, r: Int, g: Int, b: Int): Int =
            (a.coerceIn(0, 255) shl 24) or
                (r.coerceIn(0, 255) shl 16) or
                (g.coerceIn(0, 255) shl 8) or
                b.coerceIn(0, 255)
    }
}
