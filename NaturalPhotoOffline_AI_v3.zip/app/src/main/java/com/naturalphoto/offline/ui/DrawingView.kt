package com.naturalphoto.offline.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val path = Path()
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 64f
        color = Color.WHITE
    }

    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = PorterDuffColorFilter(
            Color.argb(140, 255, 64, 129),
            PorterDuff.Mode.SRC_IN
        )
    }

    private var maskBitmap: Bitmap? = null
    private var maskCanvas: Canvas? = null

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        if (w <= 0 || h <= 0) return
        maskBitmap?.recycle()
        maskBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        maskCanvas = Canvas(maskBitmap!!)
        maskCanvas?.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        maskBitmap?.let { bitmap ->
            canvas.drawBitmap(bitmap, 0f, 0f, previewPaint)
        }
        canvas.drawPath(path, strokePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                path.reset()
                path.moveTo(event.x, event.y)
                maskCanvas?.drawCircle(event.x, event.y, strokePaint.strokeWidth / 2f, strokePaint)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(event.x, event.y)
                maskCanvas?.drawPath(path, strokePaint)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                path.lineTo(event.x, event.y)
                maskCanvas?.drawPath(path, strokePaint)
                path.reset()
                invalidate()
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun setBrushSize(sizePx: Float) {
        strokePaint.strokeWidth = sizePx.coerceIn(10f, 300f)
    }

    fun clear() {
        maskCanvas?.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        path.reset()
        invalidate()
    }

    /** Returns a binary mask in original-image coordinates: 1 = erase, 0 = keep. */
    fun getEraseMaskForImage(imageWidth: Int, imageHeight: Int): ByteArray {
        val out = ByteArray(imageWidth * imageHeight)
        val source = maskBitmap ?: return out
        if (width <= 0 || height <= 0 || imageWidth <= 0 || imageHeight <= 0) return out

        val scale = min(width.toFloat() / imageWidth, height.toFloat() / imageHeight)
        val drawnW = imageWidth * scale
        val drawnH = imageHeight * scale
        val left = ((width - drawnW) / 2f).coerceAtLeast(0f)
        val top = ((height - drawnH) / 2f).coerceAtLeast(0f)

        val cropLeft = left.toInt().coerceIn(0, width - 1)
        val cropTop = top.toInt().coerceIn(0, height - 1)
        val cropRight = min(width, (left + drawnW).toInt())
        val cropBottom = min(height, (top + drawnH).toInt())
        val cropW = max(1, cropRight - cropLeft)
        val cropH = max(1, cropBottom - cropTop)

        val cropped = Bitmap.createBitmap(source, cropLeft, cropTop, cropW, cropH)
        val scaled = Bitmap.createScaledBitmap(cropped, imageWidth, imageHeight, true)
        val pixels = IntArray(imageWidth * imageHeight)
        scaled.getPixels(pixels, 0, imageWidth, 0, 0, imageWidth, imageHeight)

        for (i in pixels.indices) {
            val alpha = Color.alpha(pixels[i])
            val luminance = (0.299f * Color.red(pixels[i]) +
                0.587f * Color.green(pixels[i]) +
                0.114f * Color.blue(pixels[i]))
            out[i] = if (alpha > 16 && luminance > 20f) 1 else 0
        }

        if (scaled !== cropped) scaled.recycle()
        if (cropped !== source) cropped.recycle()
        return out
    }
}
