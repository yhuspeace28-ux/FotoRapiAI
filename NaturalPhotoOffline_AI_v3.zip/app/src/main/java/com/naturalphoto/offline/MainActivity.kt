package com.naturalphoto.offline

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.naturalphoto.offline.ai.MiGanInpainting
import com.naturalphoto.offline.ui.DrawingView
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var drawingView: DrawingView
    private lateinit var status: TextView
    private var workingBitmap: Bitmap? = null

    private val openImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        loadBitmap(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)

        imageView = findViewById(R.id.imgOriginal)
        drawingView = findViewById(R.id.drawingView)
        status = findViewById(R.id.txtStatus)

        findViewById<Button>(R.id.btnOpen).setOnClickListener {
            openImage.launch(arrayOf("image/*"))
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            drawingView.clear()
            setStatus("Mask direset")
        }

        findViewById<Button>(R.id.btnNatural).setOnClickListener {
            val source = workingBitmap ?: return@setOnClickListener
            setBusy(true, "Memproses warna natural…")
            thread {
                try {
                    val result = ColorAdjuster.natural(source)
                    runOnUiThread {
                        workingBitmap = result
                        imageView.setImageBitmap(result)
                        drawingView.clear()
                        setBusy(false, "Warna natural diterapkan")
                    }
                } catch (e: Throwable) {
                    runOnUiThread {
                        setBusy(false, "Gagal memproses warna")
                        toast(e.message ?: "Kesalahan")
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnProcessAI).setOnClickListener {
            removeObject()
        }
    }

    private fun loadBitmap(uri: Uri) {
        setBusy(true, "Membuka foto…")
        thread {
            try {
                val bitmap = contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Foto tidak bisa dibuka" }
                    BitmapFactory.decodeStream(input)
                } ?: error("Format foto tidak didukung")

                val argb = if (bitmap.config == Bitmap.Config.ARGB_8888) bitmap
                else bitmap.copy(Bitmap.Config.ARGB_8888, false)

                runOnUiThread {
                    workingBitmap?.takeIf { it !== argb }?.recycle()
                    workingBitmap = argb
                    imageView.setImageBitmap(argb)
                    drawingView.clear()
                    setBusy(false, "Foto ${argb.width}×${argb.height} — siap diedit")
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    setBusy(false, "Gagal membuka foto")
                    toast(e.message ?: "Kesalahan")
                }
            }
        }
    }

    private fun removeObject() {
        val source = workingBitmap ?: run {
            toast("Pilih foto terlebih dahulu")
            return
        }

        val mask = drawingView.getEraseMaskForImage(source.width, source.height)
        if (mask.none { it.toInt() != 0 }) {
            toast("Coret objek yang ingin dihapus terlebih dahulu")
            return
        }

        setBusy(true, "AI menghapus objek…")
        thread {
            try {
                val result = MiGanInpainting(this).removeObject(source, mask) { p ->
                    runOnUiThread { status.text = "AI memproses… $p%" }
                }
                runOnUiThread {
                    workingBitmap = result
                    imageView.setImageBitmap(result)
                    drawingView.clear()
                    setBusy(false, "Objek dihapus — resolusi ${result.width}×${result.height}")
                    saveToGallery(result)
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    setBusy(false, "AI gagal")
                    toast(e.message ?: "Model AI tidak tersedia / perangkat tidak mendukung")
                }
            }
        }
    }

    private fun saveToGallery(bitmap: Bitmap) {
        thread {
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "NaturalPhoto_$stamp.jpg"

                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/NaturalPhoto")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: error("Gagal membuat file galeri")
                try {
                    contentResolver.openOutputStream(uri).use { out ->
                        requireNotNull(out)
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 96, out)
                    }
                    values.clear()
                    values.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                } catch (e: Throwable) {
                    contentResolver.delete(uri, null, null)
                    throw e
                }

                runOnUiThread { toast("Disimpan ke Galeri/NaturalPhoto") }
            } catch (e: IOException) {
                runOnUiThread { toast("Gagal menyimpan: ${e.message}") }
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        status.text = message
        findViewById<Button>(R.id.btnOpen).isEnabled = !busy
        findViewById<Button>(R.id.btnNatural).isEnabled = !busy
        findViewById<Button>(R.id.btnClear).isEnabled = !busy
        findViewById<Button>(R.id.btnProcessAI).isEnabled = !busy
        drawingView.isEnabled = !busy
        drawingView.alpha = if (busy) 0.35f else 1f
    }

    private fun setStatus(message: String) {
        status.text = message
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        workingBitmap?.recycle()
        workingBitmap = null
        super.onDestroy()
    }
}
