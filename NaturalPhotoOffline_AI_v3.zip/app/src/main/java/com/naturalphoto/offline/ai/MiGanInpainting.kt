package com.naturalphoto.offline.ai

import android.content.Context
import android.graphics.Bitmap
import com.google.ai.edge.litert.Accelerator
import com.google.ai.edge.litert.CompiledModel
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

class MiGanInpainting(private val context: Context) {

    companion object {
        const val MODEL_ASSET = "migan_fp16.tflite"
        const val SIZE = 512
        const val OVERLAP = 128
        private const val PAD = 192
    }

    private val closed = AtomicBoolean(false)

    fun removeObject(source: Bitmap, eraseMask: ByteArray, progress: ((Int) -> Unit)? = null): Bitmap {
        require(source.config == Bitmap.Config.ARGB_8888) { "Bitmap harus ARGB_8888" }
        require(eraseMask.size == source.width * source.height) { "Ukuran mask tidak sesuai" }
        require(context.assets.list("")?.contains(MODEL_ASSET) == true) {
            "Model AI belum tersedia di APK: $MODEL_ASSET"
        }

        val bbox = findBoundingBox(eraseMask, source.width, source.height)
            ?: return source.copy(Bitmap.Config.ARGB_8888, true)

        val regionLeft = max(0, bbox[0] - PAD)
        val regionTop = max(0, bbox[1] - PAD)
        val regionRight = min(source.width, bbox[2] + PAD)
        val regionBottom = min(source.height, bbox[3] + PAD)

        val xStarts = tileStarts(regionLeft, regionRight, source.width)
        val yStarts = tileStarts(regionTop, regionBottom, source.height)
        val total = xStarts.size * yStarts.size
        var done = 0

        val accum = FloatArray(source.width * source.height * 3)
        val weights = FloatArray(source.width * source.height)

        CompiledModel.create(
            context.assets,
            MODEL_ASSET,
            CompiledModel.Options(Accelerator.GPU)
        ).use { model ->
            val inputs = model.createInputBuffers()
            val outputs = model.createOutputBuffers()
            try {
                val input = FloatArray(4 * SIZE * SIZE)
                for (y0 in yStarts) {
                    for (x0 in xStarts) {
                        java.util.Arrays.fill(input, 0f)
                        fillInput(source, eraseMask, x0, y0, input)
                        inputs[0].writeFloat(input)
                        model.run(inputs, outputs)
                        val generated = outputs[0].readFloat()
                        accumulateTile(
                            source,
                            eraseMask,
                            x0,
                            y0,
                            generated,
                            accum,
                            weights
                        )
                        done++
                        progress?.invoke(done * 100 / total)
                    }
                }
            } finally {
                inputs.forEach { it.close() }
                outputs.forEach { it.close() }
            }
        }

        closed.set(true)
        return composeResult(source, accum, weights)
    }

    private fun fillInput(
        source: Bitmap,
        eraseMask: ByteArray,
        x0: Int,
        y0: Int,
        input: FloatArray
    ) {
        val area = SIZE * SIZE
        for (y in 0 until SIZE) {
            val gy = (y0 + y).coerceIn(0, source.height - 1)
            for (x in 0 until SIZE) {
                val gx = (x0 + x).coerceIn(0, source.width - 1)
                val tileIndex = y * SIZE + x
                val sourceIndex = gy * source.width + gx
                val erase = eraseMask[sourceIndex].toInt() != 0
                val keep = if (erase) 0f else 1f
                val pixel = source.getPixel(gx, gy)
                val r = android.graphics.Color.red(pixel) / 127.5f - 1f
                val g = android.graphics.Color.green(pixel) / 127.5f - 1f
                val b = android.graphics.Color.blue(pixel) / 127.5f - 1f
                input[tileIndex] = keep - 0.5f
                input[area + tileIndex] = r * keep
                input[area * 2 + tileIndex] = g * keep
                input[area * 3 + tileIndex] = b * keep
            }
        }
    }

    private fun accumulateTile(
        source: Bitmap,
        eraseMask: ByteArray,
        x0: Int,
        y0: Int,
        generated: FloatArray,
        accum: FloatArray,
        weights: FloatArray
    ) {
        val plane = SIZE * SIZE
        for (y in 0 until SIZE) {
            val gy = y0 + y
            if (gy !in 0 until source.height) continue
            val wy = feather(y, SIZE)
            for (x in 0 until SIZE) {
                val gx = x0 + x
                if (gx !in 0 until source.width) continue
                val idx = gy * source.width + gx
                if (eraseMask[idx].toInt() == 0) continue

                val wx = feather(x, SIZE)
                val w = (wx * wy).coerceAtLeast(0.02f)
                val ti = y * SIZE + x
                val r = ((generated[ti].coerceIn(-1f, 1f) + 1f) * 127.5f)
                val g = ((generated[plane + ti].coerceIn(-1f, 1f) + 1f) * 127.5f)
                val b = ((generated[plane * 2 + ti].coerceIn(-1f, 1f) + 1f) * 127.5f)

                accum[idx * 3] += r * w
                accum[idx * 3 + 1] += g * w
                accum[idx * 3 + 2] += b * w
                weights[idx] += w
            }
        }
    }

    private fun composeResult(source: Bitmap, accum: FloatArray, weights: FloatArray): Bitmap {
        val out = source.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(source.width * source.height)
        source.getPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        for (i in pixels.indices) {
            val w = weights[i]
            if (w > 0f) {
                val r = (accum[i * 3] / w).roundToInt8()
                val g = (accum[i * 3 + 1] / w).roundToInt8()
                val b = (accum[i * 3 + 2] / w).roundToInt8()
                pixels[i] = android.graphics.Color.rgb(r, g, b)
            }
        }
        out.setPixels(pixels, 0, source.width, 0, 0, source.width, source.height)
        return out
    }

    private fun findBoundingBox(mask: ByteArray, width: Int, height: Int): IntArray? {
        var left = width
        var top = height
        var right = -1
        var bottom = -1
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                if (mask[row + x].toInt() != 0) {
                    left = min(left, x)
                    top = min(top, y)
                    right = max(right, x)
                    bottom = max(bottom, y)
                }
            }
        }
        return if (right >= left && bottom >= top) intArrayOf(left, top, right + 1, bottom + 1) else null
    }

    private fun tileStarts(start: Int, end: Int, dimension: Int): List<Int> {
        if (dimension <= SIZE) return listOf(0)
        val last = (end - SIZE).coerceAtLeast(0).coerceAtMost(dimension - SIZE)
        val result = ArrayList<Int>()
        var x = start.coerceAtMost(last)
        while (true) {
            result.add(x)
            if (x >= last) break
            x = min(last, x + (SIZE - OVERLAP))
        }
        return result.distinct()
    }

    private fun feather(p: Int, size: Int): Float {
        val d = min(p, size - 1 - p)
        val edge = OVERLAP / 2f
        return (d / edge).coerceIn(0.1f, 1f)
    }

    private fun Float.roundToInt8(): Int = kotlin.math.round(this).toInt().coerceIn(0, 255)
}
