# Natural Photo Offline v3

Android photo editor focused on natural color correction and offline AI object removal.

## Privacy
- No INTERNET permission.
- No broad gallery permissions.
- Photo access uses the Android system picker.
- AI model runs on-device.
- Results are saved through MediaStore.

## AI model
The GitHub Actions workflow downloads `migan_fp16.tflite` at build time from the LiteRT Community MI-GAN repository, then bundles it into the APK. The installed app does not need network access for inference.

Model reference: https://huggingface.co/litert-community/MI-GAN-512-Places2-LiteRT
